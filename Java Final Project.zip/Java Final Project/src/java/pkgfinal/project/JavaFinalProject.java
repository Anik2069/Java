/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java.pkgfinal.project;

import java.util.Scanner;

/**
 *
 * @author Rasel Ahmed
 */
public class JavaFinalProject {

    /**
     * @param args the command line arguments
     */
  
   
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("1. Employee Managemnet");
        System.out.println("2. Customer Management");
        System.out.println("3. Customer Account Management");
        System.out.println("4. Account Transactions");
        System.out.println("5. Exit");
        int n;
        System.out.println("Enter your choice");
        Scanner s = new Scanner(System.in);
        n=s.nextInt();
        if(n==1){
            Employee();
        
        }
        else if(n==2){
    
    }
         else if(n==3){
    
    }
         else if(n==4){
    
    }
         else if(n==5){
    
    }
         else{
             System.out.println("Invilide Input ");
         }
    }
    
}
